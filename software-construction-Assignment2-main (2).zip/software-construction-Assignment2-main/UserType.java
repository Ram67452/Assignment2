package RefectoredCode;

public enum UserType {
 REGULAR, PREMIUM, VIP
}

package RefectoredCode;

public enum PaymentType {
    CASH, CARD, BANK, OTHER
}

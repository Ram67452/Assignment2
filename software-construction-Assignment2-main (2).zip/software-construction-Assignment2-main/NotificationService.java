package RefectoredCode;

public class NotificationService {

    public void notifyUser(String user, String message) {
        System.out.println("Notification for " + user + ": " + message);
    }
}

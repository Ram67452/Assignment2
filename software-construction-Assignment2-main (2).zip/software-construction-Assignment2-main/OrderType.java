package RefectoredCode;

public enum OrderType {
    NORMAL,
    URGENT
}



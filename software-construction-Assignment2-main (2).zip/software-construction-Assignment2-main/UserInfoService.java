package RefectoredCode;

public class UserInfoService {

    public void printUser(String name, int age) {
        System.out.println("User: " + name);
        System.out.println("Age: " + age);
    }
}
